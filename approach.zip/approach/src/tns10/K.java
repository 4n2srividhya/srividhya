package tns10;

public class K {
public void msg() {
	System.out.println("hello");
}
}
