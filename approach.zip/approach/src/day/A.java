package day;

public class A {
int b=10;
int display( ) {
	return 10;
} 
static int c=5;
static void display1() {
	 System.out.println(10);
}
public static void main(String[] args) {
	int a=20;
	System.out.println(a);
	A a1=new A();
	System.out.println(a1.b);
	a1.display();
	System.out.println(A.c);
	A.display1();
}
}