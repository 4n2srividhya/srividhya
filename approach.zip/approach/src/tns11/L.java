package tns11;

public class L {
public void msg() {
	System.out.println("hello sir");
}
}
