package tns4;

class E {
	void display() {
		System.out.println("tns");
	}

}
