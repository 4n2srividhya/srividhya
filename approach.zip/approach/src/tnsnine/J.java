package tnsnine;
import tns8.*;
public class J {
public static void main(String[] args) {
	I obj=new I();
	obj.display();
}
}
