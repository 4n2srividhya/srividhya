package tns6;  //protected

public class G {
protected void display() {
	System.out.println("tns");
}
}
